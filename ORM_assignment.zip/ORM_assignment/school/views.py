from django.shortcuts import render
from .models import Student, Course, Assignment, Submission

def student_list(request):
    students = Student.objects.all()
    return render(request, "students.html", {"students": students})

def course_list(request):
    courses = Course.objects.all()
    return render(request, "courses.html", {"courses": courses})

def assignment_list(request):
    assignments = Assignment.objects.all()
    return render(request, "assignments.html", {"assignments": assignments})

def submission_list(request):
    submissions = Submission.objects.all()
    return render(request, "submissions.html", {"submissions": submissions})